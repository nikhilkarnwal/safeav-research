# SafeAV Research website

A self-contained, responsive project website. All styling and JavaScript are inside `index.html`; no build tools or external packages are required.

## Preview

Open `index.html` in a browser, or serve this folder with a local static server.

## Publish on GitHub Pages

1. Create a GitHub repository, such as `safeav-research`.
2. Upload `index.html` and `.nojekyll` to the repository root.
3. In **Settings → Pages**, choose **Deploy from a branch**, then select **main** and **/(root)**.
4. GitHub will provide the published URL after deployment. A project repository normally appears at `https://YOUR-USERNAME.github.io/safeav-research/`.

For a personal root site, name the repository `YOUR-USERNAME.github.io` instead.

## Content and future updates

The website reflects the September 2026 project-task plan: two hazards, Behavior Agent and SimLingo, six planned conditions, Town12 development, and a four-week schedule. Results are explicitly pending. The interactive demo is illustrative, not empirical evidence.

Update the results section with measured results, denominators, confidence intervals, and experiment configurations when available. Add repository and paper links only after those resources exist. Keep future directions separate from demonstrated findings.

No analytics, tracking, backend, remote fonts, or private document links are included.
